-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Počítač: m20961
-- Vytvořeno: Úte 20. říj 2026, 09:58
-- Verze serveru: 5.6.45
-- Verze PHP: 7.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `rac`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `billing_customers`
--

CREATE TABLE `billing_customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `provider` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'stripe',
  `user_id` int(11) NOT NULL,
  `provider_customer_id` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `billing_payments`
--

CREATE TABLE `billing_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `provider` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'stripe',
  `payment_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'one_off',
  `user_id` int(11) DEFAULT NULL,
  `provider_checkout_session_id` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_payment_intent_id` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_invoice_id` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_subscription_id` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_customer_id` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `amount_minor` bigint(20) NOT NULL DEFAULT '0',
  `currency` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_reference_id` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `integration_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `billing_products`
--

CREATE TABLE `billing_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `provider` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'stripe',
  `provider_product_id` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_price_id` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'one_off',
  `amount_minor` bigint(20) NOT NULL DEFAULT '0',
  `currency` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CZK',
  `billing_interval` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_interval_count` int(10) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `billing_settings`
--

CREATE TABLE `billing_settings` (
  `setting_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_secret` tinyint(1) NOT NULL DEFAULT '0',
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `billing_settings`
--

INSERT INTO `billing_settings` (`setting_key`, `setting_value`, `is_secret`, `updated_by`, `created_at`, `updated_at`) VALUES
('base_url', 'https://pavlakovalovska.eu/administrace/billing', 0, 1, '2026-10-09 13:21:54', '2026-10-16 17:05:18'),
('billing_enabled', '1', 0, 1, '2026-10-09 13:21:54', '2026-10-16 17:05:18'),
('default_currency', 'CZK', 0, 1, '2026-10-09 13:21:54', '2026-10-16 17:05:18'),
('mode', 'test', 0, 1, '2026-10-09 13:21:54', '2026-10-16 17:05:18'),
('stripe_test_publishable_key', 'v1:UmoDl+Voxgi6Wj+a+JAOLc/2O8w3kHAVGxyZwH1oegp54FujHvpokpdGuRpTGlROOzk8f/vzzlJvDLHV0tTUwyGS79rC1Mgx8mH5ziG7wCJGj/idQIM0QvWwmgLGgs/6wiVggxzrA9UO/Tff2Mx0NAZHQkEfjtD70DXecXqCKbtag3NL9nrL', 1, 1, '2026-10-15 08:02:57', '2026-10-15 08:02:57'),
('stripe_test_secret_key', 'v1:ShCCbxYdsvqjz8Qhkoj9jNOamxUOwHHT7OQAXOqBdNsAT4zVQQEU/Jus1qC6B0IASwIYoKrYUWiEHBloA8iszpc7285LsKPf1kNdwCZ6dJZELZBIffrvuJqROaVLwWHpJQAxHbAkqq+kNtUSnpAGwGnCkUMUdGBgOqieriQj6jdQjf42d9Pc', 1, 1, '2026-10-15 08:02:57', '2026-10-15 08:02:57'),
('stripe_test_webhook_secret', 'v1:LyhhxaZjK8R7+xAx2uOf7jdnicqzEmTA1hbQsgZkFCI4qp37S9A7/yWor+Fsn/DIqtbcBDmD1IUrK6O3ggPgYsE3', 1, 1, '2026-10-15 10:04:57', '2026-10-15 10:04:57');

-- --------------------------------------------------------

--
-- Struktura tabulky `billing_subscriptions`
--

CREATE TABLE `billing_subscriptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `provider` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'stripe',
  `user_id` int(11) NOT NULL,
  `billing_product_id` bigint(20) UNSIGNED DEFAULT NULL,
  `product_code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_customer_id` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_subscription_id` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_price_id` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `checkout_session_id` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `amount_minor` bigint(20) NOT NULL DEFAULT '0',
  `currency` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_interval` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_interval_count` int(10) UNSIGNED DEFAULT NULL,
  `current_period_start` datetime DEFAULT NULL,
  `current_period_end` datetime DEFAULT NULL,
  `cancel_at_period_end` tinyint(1) NOT NULL DEFAULT '0',
  `cancel_at` datetime DEFAULT NULL,
  `canceled_at` datetime DEFAULT NULL,
  `ended_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `billing_webhook_events`
--

CREATE TABLE `billing_webhook_events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `provider` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'stripe',
  `event_id` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_type` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `livemode` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'received',
  `object_id` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `received_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `processed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `contact_blocked_ips`
--

CREATE TABLE `contact_blocked_ips` (
  `id` int(10) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktura tabulky `contact_form_settings`
--

CREATE TABLE `contact_form_settings` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `recipient_email` varchar(254) NOT NULL DEFAULT '',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sender_email` varchar(254) DEFAULT NULL,
  `sender_name` varchar(120) NOT NULL DEFAULT 'RAC – kontaktní formulář',
  `email_subject` varchar(180) NOT NULL DEFAULT 'Zpráva z kontaktního formuláře'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Vypisuji data pro tabulku `contact_form_settings`
--

INSERT INTO `contact_form_settings` (`id`, `recipient_email`, `updated_at`, `sender_email`, `sender_name`, `email_subject`) VALUES
(1, 'milan.smiesko@seznam.cz', '2026-10-19 11:28:01', NULL, 'Mgr. Pavla Kovalovská', 'Zpráva z kontaktního formuláře');

-- --------------------------------------------------------

--
-- Struktura tabulky `contact_form_subjects`
--

CREATE TABLE `contact_form_subjects` (
  `id` int(10) UNSIGNED NOT NULL,
  `label_cs` varchar(150) NOT NULL,
  `label_sk` varchar(150) NOT NULL DEFAULT '',
  `label_pl` varchar(150) NOT NULL DEFAULT '',
  `label_en` varchar(150) NOT NULL DEFAULT '',
  `label_de` varchar(150) NOT NULL DEFAULT '',
  `label_fr` varchar(150) NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '100',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktura tabulky `eshop_stock_movements`
--

CREATE TABLE `eshop_stock_movements` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `variant_id` bigint(20) UNSIGNED NOT NULL,
  `change_qty` int(11) NOT NULL,
  `balance_after` int(11) NOT NULL,
  `source` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `eshop_stock_movements`
--

INSERT INTO `eshop_stock_movements` (`id`, `variant_id`, `change_qty`, `balance_after`, `source`, `note`, `user_id`, `created_at`) VALUES
(1, 41, 20, 30, 'receipt', NULL, 1, '2026-10-13 12:55:43');

-- --------------------------------------------------------

--
-- Struktura tabulky `languages`
--

CREATE TABLE `languages` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `native_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locale` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flag_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `languages`
--

INSERT INTO `languages` (`id`, `code`, `name`, `native_name`, `locale`, `flag_path`, `is_default`, `active`, `sort_order`, `created`, `updated`) VALUES
(1, 'cs', 'Čeština', 'Čeština', 'cs_CZ', NULL, 1, 1, 10, '2026-10-07 11:52:04', '2026-10-07 11:52:04'),
(2, 'sk', 'Slovenština', 'Slovenčina', 'sk_SK', NULL, 0, 1, 20, '2026-10-07 11:52:04', '2026-10-07 11:52:04'),
(3, 'pl', 'Polština', 'Polski', 'pl_PL', NULL, 0, 1, 30, '2026-10-07 11:52:04', '2026-10-07 11:52:04'),
(4, 'en', 'Angličtina', 'English', 'en_GB', NULL, 0, 1, 40, '2026-10-07 11:52:04', '2026-10-07 11:52:04'),
(5, 'de', 'Němčina', 'Deutsch', 'de_DE', NULL, 0, 1, 50, '2026-10-07 11:52:04', '2026-10-07 11:52:04'),
(6, 'fr', 'Francouzština', 'Français', 'fr_FR', 'uploads/languages/lang_5ec9ccd45b926d61ef2547e5.webp', 0, 1, 60, '2026-10-07 11:57:17', '2026-10-07 12:37:38');

-- --------------------------------------------------------

--
-- Struktura tabulky `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `pages`
--

INSERT INTO `pages` (`id`, `code`, `template`, `admin_label`, `active`, `sort_order`, `created`, `updated`) VALUES
(1, 'home', 'index.php', 'Úvodní stránka', 1, 10, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(2, 'author', 'o-autorovi.php', 'O autorovi', 1, 20, '2026-10-07 13:40:38', '2026-10-07 13:40:38'),
(3, 'contact', 'kontakt.php', 'Kontakt', 1, 30, '2026-10-07 13:55:20', '2026-10-07 13:55:20');

-- --------------------------------------------------------

--
-- Struktura tabulky `page_sections`
--

CREATE TABLE `page_sections` (
  `id` int(10) UNSIGNED NOT NULL,
  `page_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `page_sections`
--

INSERT INTO `page_sections` (`id`, `page_id`, `code`, `admin_label`, `active`, `sort_order`, `created`, `updated`) VALUES
(1, 1, 'intro', 'Myšlenka, která všechno spojuje', 1, 10, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(2, 1, 'books_intro', 'Knihy & projekty', 1, 20, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(3, 1, 'author', 'O autorovi', 1, 30, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(4, 1, 'upcoming_intro', 'Připravujeme', 1, 40, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(5, 1, 'contact', 'Kontakt', 1, 50, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(6, 1, 'audio', 'Audioukázka', 1, 60, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(7, 2, 'header', 'Hlavička stránky', 1, 10, '2026-10-07 13:40:38', '2026-10-07 13:40:38'),
(8, 2, 'content', 'Obsah stránky', 1, 20, '2026-10-07 13:40:38', '2026-10-07 13:40:38'),
(9, 3, 'header', 'Hlavička stránky', 1, 10, '2026-10-07 13:55:20', '2026-10-07 13:55:20'),
(10, 3, 'form_intro', 'Úvod kontaktního formuláře', 1, 20, '2026-10-07 13:55:20', '2026-10-07 13:55:20'),
(11, 3, 'contact_info', 'Kontaktní údaje', 1, 30, '2026-10-07 13:55:20', '2026-10-07 13:55:20');

-- --------------------------------------------------------

--
-- Struktura tabulky `page_section_fields`
--

CREATE TABLE `page_section_fields` (
  `id` int(10) UNSIGNED NOT NULL,
  `section_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `page_section_fields`
--

INSERT INTO `page_section_fields` (`id`, `section_id`, `code`, `admin_label`, `field_type`, `required`, `sort_order`, `created`, `updated`) VALUES
(1, 1, 'tagline', 'Malý nadpis', 'text', 1, 10, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(2, 1, 'title', 'Hlavní nadpis', 'textarea', 1, 20, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(3, 1, 'quote', 'Text / citát', 'textarea', 1, 30, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(4, 2, 'tagline', 'Malý nadpis', 'text', 1, 10, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(5, 2, 'title', 'Hlavní nadpis', 'text', 1, 20, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(6, 2, 'formats', 'Dostupné formáty', 'textarea', 1, 30, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(7, 3, 'tagline', 'Malý nadpis', 'text', 1, 10, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(8, 3, 'title', 'Hlavní nadpis', 'text', 1, 20, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(9, 3, 'text_one', 'První odstavec', 'textarea', 1, 30, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(10, 3, 'text_two', 'Druhý odstavec', 'textarea', 1, 40, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(11, 4, 'tagline', 'Malý nadpis', 'text', 1, 10, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(12, 4, 'title', 'Hlavní nadpis', 'text', 1, 20, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(13, 4, 'quote', 'Text / citát', 'textarea', 1, 30, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(14, 5, 'tagline', 'Malý nadpis', 'text', 1, 10, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(15, 5, 'title', 'Hlavní nadpis', 'textarea', 1, 20, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(16, 6, 'image_alt', 'Alternativní text obrázku', 'text', 0, 10, '2026-10-07 13:28:24', '2026-10-07 13:28:24'),
(17, 7, 'title', 'Nadpis stránky', 'text', 1, 10, '2026-10-07 13:40:38', '2026-10-07 13:40:38'),
(18, 8, 'heading', 'Hlavní nadpis', 'text', 1, 10, '2026-10-07 13:40:38', '2026-10-07 13:40:38'),
(19, 8, 'text', 'Text O autorovi', 'textarea', 0, 20, '2026-10-07 13:40:39', '2026-10-07 13:40:39'),
(20, 9, 'title', 'Nadpis stránky', 'text', 1, 10, '2026-10-07 13:55:20', '2026-10-07 13:55:20'),
(21, 10, 'tagline', 'Malý nadpis', 'text', 1, 10, '2026-10-07 13:55:20', '2026-10-07 13:55:20'),
(22, 10, 'title', 'Hlavní nadpis', 'textarea', 1, 20, '2026-10-07 13:55:20', '2026-10-07 13:55:20'),
(23, 11, 'address', 'Adresa', 'textarea', 0, 10, '2026-10-07 13:55:20', '2026-10-07 13:55:20'),
(24, 11, 'email', 'E-mail', 'text', 0, 20, '2026-10-07 13:55:20', '2026-10-07 13:55:20'),
(25, 11, 'phone', 'Telefon', 'text', 0, 30, '2026-10-07 13:55:20', '2026-10-07 13:55:20'),
(26, 11, 'company_info', 'IČ / DIČ / další údaje', 'textarea', 0, 40, '2026-10-07 13:55:20', '2026-10-07 13:55:20');

-- --------------------------------------------------------

--
-- Struktura tabulky `page_section_field_translations`
--

CREATE TABLE `page_section_field_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `field_id` int(10) UNSIGNED NOT NULL,
  `language_id` int(10) UNSIGNED NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `page_section_field_translations`
--

INSERT INTO `page_section_field_translations` (`id`, `field_id`, `language_id`, `value`, `created`, `updated`) VALUES
(1, 16, 1, 'Audioukázka', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(2, 7, 1, 'O autorovi', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(3, 9, 1, 'Pavla Kovalovská je český autor, který ve své tvorbě zkoumá člověka, lidské vztahy a otázky, na které neexistují pohodlné odpovědi.', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(4, 10, 1, 'Jeho autorský svět propojuje sebepoznání, lásku, rodinu i kritický pohled na společnost. Každý rukopis stojí na přesvědčení, že silný příběh nezačíná efektem, ale opravdovostí.', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(5, 8, 1, 'Slova mají smysl, když v nich poznáš život.', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(6, 6, 1, 'Knihy jsou dostupné v těchto podobách:\r\nElektronická kniha / Tištěná kniha / Audiokniha', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(7, 4, 1, 'Autorský svět', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(8, 5, 1, 'Knihy & projekty', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(9, 14, 1, 'Některé věci začínají jednou zprávou.', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(10, 15, 1, 'Pro vydavatelské nabídky, spolupráci a dotazy ke knihám můžeš autora kontaktovat přímo e-mailem.', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(11, 3, 1, 'Každá kniha otevírá jinou kapitolu lidského života. Sebepoznání, láska, rodina, společnost i odvaha podívat se pravdě do očí. Jednotlivé příběhy. Jedna společná cesta.', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(12, 1, 1, 'Myšlenka, která všechno spojuje', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(13, 2, 1, 'Nejdelší cesta nevede přes svět.\r\nVede do člověka.', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(14, 13, 1, 'Pavla Kovalovská', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(15, 11, 1, 'Další kapitoly', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(16, 12, 1, 'Na čem se pracuje', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(33, 1, 2, 'Myšlienka, ktorá všetko spája', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(34, 1, 3, 'Myśl, która łączy wszystko', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(35, 1, 4, 'The idea that connects everything', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(36, 1, 5, 'Der Gedanke, der alles verbindet', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(37, 1, 6, 'L’idée qui relie tout', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(39, 2, 2, 'Najdlhšia cesta nevedie cez svet.\r\nVedie do človeka.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(40, 2, 3, 'Najdłuższa droga nie prowadzi przez świat.\r\nProwadzi do człowieka.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(41, 2, 4, 'The longest journey does not lead through the world.\r\nIt leads into a person.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(42, 2, 5, 'Der längste Weg führt nicht durch die Welt.\r\nEr führt in den Menschen.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(43, 2, 6, 'Le plus long voyage ne mène pas à travers le monde.\r\nIl mène au cœur de l’être humain.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(45, 3, 2, 'Každá kniha otvára inú kapitolu ľudského života. Sebapoznanie, láska, rodina, spoločnosť aj odvaha pozrieť sa pravde do očí. Jednotlivé príbehy. Jedna spoločná cesta.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(46, 3, 3, 'Każda książka otwiera inny rozdział ludzkiego życia. Samopoznanie, miłość, rodzina, społeczeństwo i odwaga, by spojrzeć prawdzie w oczy. Różne historie. Jedna wspólna droga.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(47, 3, 4, 'Every book opens a different chapter of human life. Self-discovery, love, family, society, and the courage to face the truth. Different stories. One shared journey.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(48, 3, 5, 'Jedes Buch öffnet ein anderes Kapitel des menschlichen Lebens. Selbsterkenntnis, Liebe, Familie, Gesellschaft und der Mut, der Wahrheit ins Auge zu sehen. Unterschiedliche Geschichten. Ein gemeinsamer Weg.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(49, 3, 6, 'Chaque livre ouvre un chapitre différent de la vie humaine. La connaissance de soi, l’amour, la famille, la société et le courage de regarder la vérité en face. Des histoires différentes. Un chemin commun.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(51, 4, 2, 'Autorský svet', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(52, 4, 3, 'Świat autora', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(53, 4, 4, 'The Author’s World', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(54, 4, 5, 'Die Welt des Autors', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(55, 4, 6, 'L’univers de l’auteur', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(57, 5, 2, 'Knihy & projekty', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(58, 5, 3, 'Książki i projekty', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(59, 5, 4, 'Books & Projects', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(60, 5, 5, 'Bücher & Projekte', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(61, 5, 6, 'Livres & projets', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(63, 6, 2, 'Knihy sú dostupné v týchto podobách:\r\nElektronická kniha / Tlačená kniha / Audiokniha', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(64, 6, 3, 'Książki są dostępne w następujących formatach:\r\nE-book / Książka drukowana / Audiobook', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(65, 6, 4, 'Books are available in the following formats:\r\nE-book / Printed book / Audiobook', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(66, 6, 5, 'Die Bücher sind in folgenden Formaten erhältlich:\r\nE-Book / Gedrucktes Buch / Hörbuch', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(67, 6, 6, 'Les livres sont disponibles dans les formats suivants :\r\nLivre numérique / Livre imprimé / Livre audio', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(69, 7, 2, 'O autorovi', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(70, 7, 3, 'O autorze', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(71, 7, 4, 'About the Author', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(72, 7, 5, 'Über den Autor', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(73, 7, 6, 'À propos de l’auteur', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(75, 8, 2, 'Slová majú zmysel, keď v nich spoznáš život.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(76, 8, 3, 'Słowa mają sens, gdy odnajdujesz w nich życie.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(77, 8, 4, 'Words have meaning when you recognize life in them.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(78, 8, 5, 'Worte haben Bedeutung, wenn du in ihnen das Leben erkennst.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(79, 8, 6, 'Les mots prennent tout leur sens lorsque tu y reconnais la vie.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(81, 9, 2, 'Pavla Kovalovská je český autor, ktorý vo svojej tvorbe skúma človeka, medziľudské vzťahy a otázky, na ktoré neexistujú jednoduché odpovede.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(82, 9, 3, 'Pavla Kovalovská jest czeskim autorem, który w swojej twórczości zgłębia naturę człowieka, relacje międzyludzkie oraz pytania, na które nie ma łatwych odpowiedzi.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(83, 9, 4, 'Pavla Kovalovská is a Czech author whose work explores human nature, relationships, and questions that have no easy answers.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(84, 9, 5, 'Pavla Kovalovská ist ein tschechischer Autor, der sich in seinem Werk mit dem Menschen, zwischenmenschlichen Beziehungen und Fragen beschäftigt, auf die es keine einfachen Antworten gibt.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(85, 9, 6, 'Pavla Kovalovská est un auteur tchèque qui explore dans son œuvre la nature humaine, les relations entre les personnes et les questions auxquelles il n’existe pas de réponses faciles.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(87, 10, 2, 'Jeho autorský svet prepája sebapoznanie, lásku, rodinu aj kritický pohľad na spoločnosť. Každý rukopis vychádza z presvedčenia, že silný príbeh sa nezačína efektom, ale úprimnosťou.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(88, 10, 3, 'Jego autorski świat łączy samopoznanie, miłość, rodzinę oraz krytyczne spojrzenie na społeczeństwo. Każdy rękopis opiera się na przekonaniu, że mocna historia nie zaczyna się od efektu, lecz od autentyczności.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(89, 10, 4, 'His creative world brings together self-discovery, love, family, and a critical view of society. Every manuscript is built on the belief that a powerful story begins not with spectacle, but with authenticity.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(90, 10, 5, 'Seine Autorenwelt verbindet Selbsterkenntnis, Liebe, Familie und einen kritischen Blick auf die Gesellschaft. Jedes Manuskript beruht auf der Überzeugung, dass eine starke Geschichte nicht mit Effekten beginnt, sondern mit Authentizität.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(91, 10, 6, 'Son univers d’auteur réunit la connaissance de soi, l’amour, la famille et un regard critique sur la société. Chaque manuscrit repose sur la conviction qu’une histoire forte ne commence pas par l’effet, mais par l’authenticité.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(93, 11, 2, 'Ďalšie kapitoly', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(94, 11, 3, 'Kolejne rozdziały', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(95, 11, 4, 'Next Chapters', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(96, 11, 5, 'Weitere Kapitel', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(97, 11, 6, 'Prochains chapitres', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(99, 12, 2, 'Na čom sa pracuje', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(100, 12, 3, 'Nad czym trwają prace', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(101, 12, 4, 'What’s in Progress', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(102, 12, 5, 'Woran gearbeitet wird', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(103, 12, 6, 'Ce qui est en cours', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(105, 13, 2, 'Pavla Kovalovská', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(106, 13, 3, 'Pavla Kovalovská', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(107, 13, 4, 'Pavla Kovalovská', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(108, 13, 5, 'Pavla Kovalovská', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(109, 13, 6, 'Pavla Kovalovská', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(111, 14, 2, 'Některé věci začínají jednou zprávou.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(112, 14, 3, 'Niektóre rzeczy zaczynają się od jednej wiadomości.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(113, 14, 4, 'Some things begin with a single message.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(114, 14, 5, 'Manche Dinge beginnen mit einer einzigen Nachricht.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(115, 14, 6, 'Certaines choses commencent par un simple message.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(117, 15, 2, 'V prípade vydavateľských ponúk, spolupráce a otázok ku knihám môžeš autora kontaktovať priamo e-mailom.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(118, 15, 3, 'W sprawie ofert wydawniczych, współpracy i pytań dotyczących książek możesz skontaktować się z autorem bezpośrednio przez e-mail.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(119, 15, 4, 'For publishing offers, collaborations, and questions about the books, you can contact the author directly by email.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(120, 15, 5, 'Für Verlagsangebote, Kooperationen und Fragen zu den Büchern kannst du den Autor direkt per E-Mail kontaktieren.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(121, 15, 6, 'Pour les propositions d’édition, les collaborations et les questions concernant les livres, tu peux contacter l’auteur directement par e-mail.', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(123, 16, 2, 'Audioukážka', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(124, 16, 3, 'Fragment audiobooka', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(125, 16, 4, 'Audio Sample', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(126, 16, 5, 'Hörprobe', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(127, 16, 6, 'Extrait audio', '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(224, 18, 1, 'Připravujeme...', '2026-10-07 13:40:39', '2026-10-07 13:55:50'),
(225, 19, 1, NULL, '2026-10-07 13:40:39', '2026-10-07 13:55:50'),
(226, 17, 1, 'Štefan Rác', '2026-10-07 13:40:39', '2026-10-07 13:55:50'),
(324, 17, 2, 'Štefan Rác', '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(325, 17, 3, 'Štefan Rác', '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(326, 17, 4, 'Štefan Rác', '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(327, 17, 5, 'Štefan Rác', '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(328, 17, 6, 'Štefan Rác', '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(330, 18, 2, 'Pripravujeme...', '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(331, 18, 3, 'W przygotowaniu...', '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(332, 18, 4, 'Coming soon...', '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(333, 18, 5, 'In Vorbereitung...', '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(334, 18, 6, 'À venir...', '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(336, 19, 2, NULL, '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(337, 19, 3, NULL, '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(338, 19, 4, NULL, '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(339, 19, 5, NULL, '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(340, 19, 6, NULL, '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(395, 23, 1, 'ulice + č.popisné\r\nKarvniná, ČR', '2026-10-07 13:55:20', '2026-10-13 13:06:49'),
(396, 26, 1, 'IČ: aktualizujeme...\r\nDIČ: aktualizujeme...', '2026-10-07 13:55:20', '2026-10-13 13:06:49'),
(397, 24, 1, 'stefan.rac1@gmail.com', '2026-10-07 13:55:20', '2026-10-13 13:06:49'),
(398, 25, 1, '+420 608 472 587', '2026-10-07 13:55:20', '2026-10-13 13:06:49'),
(399, 21, 1, 'Kontaktní formulář', '2026-10-07 13:55:20', '2026-10-13 13:06:49'),
(400, 22, 1, 'Pro vydavatelské nabídky, spolupráci a dotazy ke knihám můžeš autora kontaktovat.', '2026-10-07 13:55:20', '2026-10-13 13:06:49'),
(401, 20, 1, 'Kontaktní informace', '2026-10-07 13:55:20', '2026-10-13 13:06:49'),
(421, 20, 2, 'Kontaktné informácie', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(422, 20, 3, 'Informacje kontaktowe', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(423, 20, 4, 'Contact Information', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(424, 20, 5, 'Kontaktinformationen', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(425, 20, 6, 'Coordonnées', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(427, 21, 2, 'Kontaktný formulár', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(428, 21, 3, 'Formularz kontaktowy', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(429, 21, 4, 'Contact Form', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(430, 21, 5, 'Kontaktformular', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(431, 21, 6, 'Formulaire de contact', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(433, 22, 2, 'V prípade vydavateľských ponúk, spolupráce a otázok ku knihám môžeš autora kontaktovať.', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(434, 22, 3, 'W sprawie ofert wydawniczych, współpracy i pytań dotyczących książek możesz skontaktować się z autorem.', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(435, 22, 4, 'For publishing offers, collaborations, and questions about the books, you can contact the author.', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(436, 22, 5, 'Für Verlagsangebote, Kooperationen und Fragen zu den Büchern kannst du den Autor kontaktieren.', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(437, 22, 6, 'Pour les propositions d’édition, les collaborations et les questions concernant les livres, tu peux contacter l’auteur.', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(439, 23, 2, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(440, 23, 3, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(441, 23, 4, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(442, 23, 5, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(443, 23, 6, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(445, 24, 2, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(446, 24, 3, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(447, 24, 4, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(448, 24, 5, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(449, 24, 6, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(451, 25, 2, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(452, 25, 3, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(453, 25, 4, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(454, 25, 5, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(455, 25, 6, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(457, 26, 2, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(458, 26, 3, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(459, 26, 4, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(460, 26, 5, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(461, 26, 6, NULL, '2026-10-07 13:59:04', '2026-10-13 13:06:49');

-- --------------------------------------------------------

--
-- Struktura tabulky `page_translations`
--

CREATE TABLE `page_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `page_id` int(10) UNSIGNED NOT NULL,
  `language_id` int(10) UNSIGNED NOT NULL,
  `page_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `page_translations`
--

INSERT INTO `page_translations` (`id`, `page_id`, `language_id`, `page_title`, `slug`, `meta_title`, `meta_description`, `created`, `updated`) VALUES
(1, 1, 1, 'Úvodní stránka', NULL, 'RAC', 'Knihy a audioknihy', '2026-10-07 13:28:24', '2026-10-19 13:26:47'),
(3, 1, 2, NULL, NULL, NULL, NULL, '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(4, 1, 3, NULL, NULL, NULL, NULL, '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(5, 1, 4, NULL, NULL, NULL, NULL, '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(6, 1, 5, NULL, NULL, NULL, NULL, '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(7, 1, 6, NULL, NULL, NULL, NULL, '2026-10-07 13:33:15', '2026-10-19 13:26:47'),
(14, 2, 1, 'O autorovi', 'o-autorovi', 'Štefan Rác | O autorovi', 'Informace o autorovi Štefanu Rácovi a jeho tvorbě.', '2026-10-07 13:40:38', '2026-10-07 13:55:50'),
(22, 2, 2, 'O autorovi', NULL, 'O autorovi', 'Informácie o autorovi Štefanovi Rácovi a jeho tvorbe.', '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(23, 2, 3, 'O autorze', NULL, 'O autorze', 'Informacje o autorze Štefanie Rácu i jego twórczości.', '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(24, 2, 4, 'About the Author', NULL, 'About the Author', 'Information about the author Štefan Rác and his work.', '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(25, 2, 5, 'Über den Autor', NULL, 'Über den Autor', 'Informationen über den Autor Štefan Rác und sein Werk.', '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(26, 2, 6, 'À propos de l’auteur', NULL, 'À propos de l’auteur', 'Informations sur l’auteur Štefan Rác et son œuvre.', '2026-10-07 13:41:36', '2026-10-07 13:55:50'),
(45, 3, 1, 'Kontaktné informácie', 'kontakt', 'Štefan Rác | Kontakt', 'Kontaktní informace a formulář pro spojení s autorem Štefanem Rácem.', '2026-10-07 13:55:20', '2026-10-13 13:06:49'),
(53, 3, 2, 'Kontaktné informácie', NULL, 'Kontaktné informácie', 'Kontaktné informácie', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(54, 3, 3, 'Informacje kontaktowe', NULL, 'Informacje kontaktowe', 'Informacje kontaktowe', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(55, 3, 4, 'Contact Information', NULL, 'Contact Information', 'Contact Information', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(56, 3, 5, 'Kontaktinformationen', NULL, 'Kontaktinformationen', 'Kontaktinformationen', '2026-10-07 13:59:04', '2026-10-13 13:06:49'),
(57, 3, 6, 'Coordonnées', NULL, 'Coordonnées', 'Coordonnées', '2026-10-07 13:59:04', '2026-10-13 13:06:49');

-- --------------------------------------------------------

--
-- Struktura tabulky `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `release_date` date DEFAULT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` enum('draft','active','hidden','sold_out') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `products`
--

INSERT INTO `products` (`id`, `slug`, `author`, `release_date`, `category_id`, `status`, `featured`, `sort_order`, `created`, `updated`) VALUES
(1, 'poznej-sam-sebe-pak-pochopis-vsechno', 'Mgr. Pavla Kovalovská', '2026-10-01', NULL, 'active', 0, 1, '2026-10-08 09:26:23', '2026-10-16 18:20:25'),
(2, 'poznej-sam-sebe-pak-pochopis-vsechno-komunikace-se-sebou', 'Mgr. Pavla Kovalovská', '2026-10-01', NULL, 'active', 0, 2, '2026-10-09 07:20:24', '2026-10-16 18:20:32'),
(3, 'poznej-sam-sebe-pak-pochopis-vsechno-rozsirena-verze', 'Mgr. Pavla Kovalovská', '2026-09-11', NULL, 'active', 0, 3, '2026-10-09 10:21:09', '2026-10-16 18:20:39'),
(4, 'laska', 'Mgr. Pavla Kovalovská', NULL, NULL, 'active', 0, 0, '2026-10-12 06:55:52', '2026-10-16 18:20:19'),
(5, 'zivot', 'Mgr. Pavla Kovalovská', NULL, NULL, 'active', 0, 0, '2026-10-12 06:59:33', '2026-10-16 18:20:10'),
(6, 'laska-prvni-dil-koma', 'Mgr. Pavla Kovalovská', NULL, NULL, 'draft', 0, 0, '2026-10-12 07:02:10', '2026-10-16 18:20:03'),
(7, 'civilioza', 'Mgr. Pavla Kovalovská', NULL, NULL, 'draft', 0, 0, '2026-10-12 07:08:55', '2026-10-16 18:19:56'),
(8, 'stupne-vedomi', 'Mgr. Pavla Kovalovská', NULL, NULL, 'draft', 0, 0, '2026-10-12 07:09:51', '2026-10-16 18:19:47'),
(9, 'mezi-psychopaty', 'Mgr. Pavla Kovalovská', NULL, NULL, 'active', 0, 0, '2026-10-12 07:11:26', '2026-10-12 07:11:26');

-- --------------------------------------------------------

--
-- Struktura tabulky `product_categories`
--

CREATE TABLE `product_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `product_category_translations`
--

CREATE TABLE `product_category_translations` (
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `language_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `product_files`
--

CREATE TABLE `product_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `variant_id` bigint(20) UNSIGNED NOT NULL,
  `purpose` enum('paid','preview') COLLATE utf8mb4_unicode_ci NOT NULL,
  `media_type` enum('pdf','epub','mp3','m4a') COLLATE utf8mb4_unicode_ci NOT NULL,
  `storage_key` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` bigint(20) UNSIGNED NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `product_files`
--

INSERT INTO `product_files` (`id`, `variant_id`, `purpose`, `media_type`, `storage_key`, `original_filename`, `mime_type`, `file_size`, `created`) VALUES
(1, 42, 'paid', 'pdf', '9e81a7715c612ac3921b70c25758815ad13286b8789ce62d', 'testovaci_ebook.pdf', 'application/pdf', 2801, '2026-10-16 07:51:43'),
(2, 24, 'paid', 'mp3', '1036f50d040cb38ece79aaaab3a6df2db663a2fe671428d5', 'testovaci_audiokniha.mp3', 'audio/mpeg', 16602, '2026-10-16 07:51:58'),
(3, 42, 'preview', 'pdf', '2bd90fc5df429ea8ee59f949e26e2857685c75364ada2a00', 'testovaci_ebook -ukazka.pdf', 'application/pdf', 2801, '2026-10-16 07:52:13');

-- --------------------------------------------------------

--
-- Struktura tabulky `product_images`
--

CREATE TABLE `product_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alt_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `file_path`, `alt_text`, `is_primary`, `sort_order`, `created`) VALUES
(1, 1, 'uploads/products/c5c9f6ca31568960b0ebd25f8ff3c1b6.webp', 'Poznej sám sebe a pak pochopíš všechno', 1, 10, '2026-10-08 09:37:00'),
(2, 2, 'uploads/products/e20c799037dbcb77cb65b2c511d80535.webp', NULL, 1, 10, '2026-10-09 07:22:53'),
(3, 2, 'uploads/products/1561674ce3144fdbb0fbdef320b80fc2.webp', NULL, 0, 20, '2026-10-09 07:33:29'),
(4, 3, 'uploads/products/75037ab96d5e9a0001d921e9decc6882.webp', NULL, 1, 10, '2026-10-09 10:21:47'),
(5, 4, 'uploads/products/9f2228c8af21a0b780971bc7aa5cfc63.webp', NULL, 1, 10, '2026-10-12 06:57:07'),
(6, 5, 'uploads/products/cd0864208f2815e109bc5e951be8d22a.webp', NULL, 1, 10, '2026-10-12 07:00:04'),
(7, 6, 'uploads/products/a8ba246d753d971b32fe039f7dc04657.webp', NULL, 1, 10, '2026-10-12 07:02:25'),
(8, 9, 'uploads/products/3d6f46dbafa967913e68090d8211f03f.webp', NULL, 1, 10, '2026-10-12 07:11:42'),
(9, 8, 'uploads/products/9e2936fe9b261504f07ba9ee1b719e40.webp', NULL, 1, 10, '2026-10-12 09:11:41'),
(10, 7, 'uploads/products/e0ff2559e49b7707ec0b2ed257ed792e.webp', NULL, 1, 10, '2026-10-12 09:13:49');

-- --------------------------------------------------------

--
-- Struktura tabulky `product_translations`
--

CREATE TABLE `product_translations` (
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `language_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `short_description` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci,
  `seo_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description` varchar(320) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `product_translations`
--

INSERT INTO `product_translations` (`product_id`, `language_id`, `title`, `short_description`, `description`, `seo_title`, `seo_description`, `updated`) VALUES
(1, 1, 'Poznej sám sebe. Pak pochopíš všechno.', 'Klasická verze knihy o sebepoznání, životě a porozumění sobě i druhým.', 'Připravujeme.....', 'Poznej sám sebe. Pak pochopíš všechno.', 'Poznej sám sebe. Pak pochopíš všechno.', '2026-10-08 09:27:26'),
(1, 2, 'Spoznaj sám seba. Potom pochopíš všetko.', 'Klasická verzia knihy o sebapoznaní, živote a porozumení sebe aj druhým.', 'Ďalšie informácie, ukážky a odkazy na nákup budú doplnené, hneď ako budú k dispozícii.', NULL, NULL, '2026-10-12 09:51:54'),
(1, 3, 'Poznaj samego siebie. Wtedy zrozumiesz wszystko.', 'Klasyczna wersja książki o samopoznaniu, życiu oraz zrozumieniu siebie i innych.', 'Dodatkowe informacje, fragmenty książki oraz linki do zakupu zostaną dodane, gdy tylko będą dostępne.', NULL, NULL, '2026-10-12 09:51:54'),
(1, 4, 'Know Yourself. Then You\'ll Understand Everything.', 'The classic edition of a book about self-discovery, life, and understanding yourself and others.', 'Additional information, previews, and purchase links will be added as soon as they become available.', NULL, NULL, '2026-10-12 09:51:54'),
(1, 5, 'Erkenne dich selbst. Dann wirst du alles verstehen.', 'Die klassische Ausgabe eines Buches über Selbsterkenntnis, das Leben und das Verständnis für sich selbst und andere.', 'Weitere Informationen, Leseproben und Kauflinks werden ergänzt, sobald sie verfügbar sind.', NULL, NULL, '2026-10-12 09:51:54'),
(1, 6, 'Connais-toi toi-même. Alors tu comprendras tout.', 'La version classique d\'un livre sur la connaissance de soi, la vie et la compréhension de soi-même et des autres.', 'Des informations complémentaires, des extraits et des liens d\'achat seront ajoutés dès qu\'ils seront disponibles.', NULL, NULL, '2026-10-12 09:51:54'),
(2, 1, 'Poznej sám sebe. Pak pochopíš všechno. — Komunikace se sebou', 'Samostatná verze zaměřená na vnitřní rozhovor, naslouchání sobě a opravdové otázky.', 'Další informace, ukázky a odkazy na nákup budou doplněny, jakmile budou k dispozici.', 'Poznej sám sebe. Pak pochopíš všechno. — Komunikace se sebou', 'Poznej sám sebe. Pak pochopíš všechno. — Komunikace se sebou', '2026-10-12 09:49:48'),
(2, 2, 'Spoznaj sám seba. Potom pochopíš všetko. — Komunikácia so sebo', 'Samostatná verzia zameraná na vnútorný rozhovor, načúvanie sebe samému a skutočné otázky.', 'Ďalšie informácie, ukážky a odkazy na nákup budú doplnené, hneď ako budú k dispozícii.', NULL, NULL, '2026-10-12 09:49:48'),
(2, 3, 'Poznaj samego siebie. Wtedy zrozumiesz wszystko. — Komunikacja z samym sobą', 'Samodzielna wersja skupiająca się na wewnętrznym dialogu, wsłuchiwaniu się w siebie i zadawaniu istotnych pytań.', 'Dodatkowe informacje, fragmenty książki oraz linki do zakupu zostaną dodane, gdy tylko będą dostępne.', NULL, NULL, '2026-10-12 09:49:48'),
(2, 4, 'Know Yourself. Then You\'ll Understand Everything. — Communicating with Yourself', 'A standalone edition focused on inner dialogue, listening to yourself, and asking meaningful questions.', 'Additional information, previews, and purchase links will be added as soon as they become available.', NULL, NULL, '2026-10-12 09:49:48'),
(2, 5, 'Erkenne dich selbst. Dann wirst du alles verstehen. — Kommunikation mit sich selbst', 'Eine eigenständige Ausgabe, die sich auf den inneren Dialog, das Hören auf sich selbst und auf wesentliche Fragen konzentriert.', 'Weitere Informationen, Leseproben und Kauflinks werden ergänzt, sobald sie verfügbar sind.', NULL, NULL, '2026-10-12 09:49:48'),
(2, 6, 'Connais-toi toi-même. Alors tu comprendras tout. — Communiquer avec soi-même', 'Une édition indépendante consacrée au dialogue intérieur, à l\'écoute de soi et aux questions essentielles.', 'Des informations complémentaires, des extraits et des liens d\'achat seront ajoutés dès qu\'ils seront disponibles.', NULL, NULL, '2026-10-12 09:49:48'),
(3, 1, 'Poznej sám sebe. Pak pochopíš všechno. — Rozšířená verze', 'Rozsáhlá podoba knihy, která jde ještě hlouběji do člověka, jeho života a vztahů.', 'Další informace, ukázky a odkazy na nákup budou doplněny, jakmile budou k dispozici.', 'Poznej sám sebe. Pak pochopíš všechno. — Rozšířená verze', 'Poznej sám sebe. Pak pochopíš všechno. — Rozšířená verze', '2026-10-12 09:47:41'),
(3, 2, 'Spoznaj sám seba. Potom pochopíš všetko. — Rozšírená verzia', 'Rozšírená podoba knihy, ktorá preniká ešte hlbšie do človeka, jeho života a vzťahov.', 'Ďalšie informácie, ukážky a odkazy na nákup budú doplnené, hneď ako budú k dispozícii.', NULL, NULL, '2026-10-12 09:47:41'),
(3, 3, 'Poznaj samego siebie. Wtedy zrozumiesz wszystko. — Wersja rozszerzona', 'Rozszerzona wersja książki, która jeszcze głębiej zgłębia ludzką naturę, życie i relacje międzyludzkie.', 'Dodatkowe informacje, fragmenty książki oraz linki do zakupu zostaną dodane, gdy tylko będą dostępne.', NULL, NULL, '2026-10-12 09:47:41'),
(3, 4, 'Know Yourself. Then You\'ll Understand Everything. — Expanded Edition', 'An expanded edition of the book that delves even deeper into human nature, life, and relationships.', 'Additional information, previews, and purchase links will be added as soon as they become available.', NULL, NULL, '2026-10-12 09:47:41'),
(3, 5, 'Erkenne dich selbst. Dann wirst du alles verstehen. — Erweiterte Ausgabe', 'Eine erweiterte Fassung des Buches, die noch tiefer in die menschliche Natur, das Leben und die zwischenmenschlichen Beziehungen eintaucht.', 'Weitere Informationen, Leseproben und Kauflinks werden ergänzt, sobald sie verfügbar sind.', NULL, NULL, '2026-10-12 09:47:41'),
(3, 6, 'Connais-toi toi-même. Alors tu comprendras tout. — Édition augmentée', 'Une version enrichie du livre qui explore encore plus profondément la nature humaine, la vie et les relations humaines.', 'Des informations complémentaires, des extraits et des liens d\'achat seront ajoutés dès qu\'ils seront disponibles.', NULL, NULL, '2026-10-12 09:47:41'),
(4, 1, 'Láska', 'Kniha o rodině, dvojčatech a lidských osudech, které se postupně propojují.', 'Další informace, ukázky a odkazy na nákup budou doplněny, jakmile budou k dispozici.', 'Láska', 'Láska', '2026-10-12 06:55:52'),
(4, 2, 'Láska', 'Kniha o rodine, dvojčatách a ľudských osudoch, ktoré sa postupne prepájajú.', 'Ďalšie informácie, ukážky a odkazy na nákup budú doplnené, hneď ako budú k dispozícii.', NULL, NULL, '2026-10-12 09:53:18'),
(4, 3, 'Miłość', 'Książka o rodzinie, bliźniętach i ludzkich losach, które stopniowo się splatają.', 'Dodatkowe informacje, przykłady oraz linki do zakupu zostaną uzupełnione, gdy tylko będą dostępne.', NULL, NULL, '2026-10-12 09:53:18'),
(4, 4, 'Love', 'A book about family, twins, and human lives whose paths gradually intertwine.', 'Additional information, previews, and purchase links will be added as soon as they become available.', NULL, NULL, '2026-10-12 09:53:18'),
(4, 5, 'Liebe', 'Ein Buch über Familie, Zwillinge und menschliche Schicksale, die sich nach und nach miteinander verweben.', 'Weitere Informationen, Leseproben und Kauflinks werden ergänzt, sobald sie verfügbar sind.', NULL, NULL, '2026-10-12 09:53:18'),
(4, 6, 'L\'Amour', 'Un livre sur la famille, les jumeaux et les destins humains qui s\'entrelacent peu à peu.', 'Des informations complémentaires, des extraits et des liens d\'achat seront ajoutés dès qu\'ils seront disponibles.', NULL, NULL, '2026-10-12 09:53:18'),
(5, 1, 'Život', 'Kniha o rodině, dvojčatech a lidských osudech, které se postupně propojují.', 'Další informace, ukázky a odkazy na nákup budou doplněny, jakmile budou k dispozici.', 'Život', 'Život', '2026-10-12 06:59:33'),
(5, 2, 'Život', 'Kniha o rodine, dvojčatách a ľudských osudoch, ktoré sa postupne prepájajú.', 'Ďalšie informácie, ukážky a odkazy na nákup budú doplnené, hneď ako budú k dispozícii.', NULL, NULL, '2026-10-12 09:42:57'),
(5, 3, 'Życie', 'Książka o rodzinie, bliźniętach i ludzkich losach, które stopniowo się splatają.', 'Dodatkowe informacje, przykłady oraz linki do zakupu zostaną uzupełnione, gdy tylko będą dostępne.', NULL, NULL, '2026-10-12 09:42:17'),
(5, 4, 'Life', 'A book about family, twins, and human lives whose paths gradually intertwine.', 'Additional information, previews, and purchase links will be added as soon as they become available.', NULL, NULL, '2026-10-12 09:42:57'),
(5, 5, 'Leben', 'Ein Buch über Familie, Zwillinge und menschliche Schicksale, die sich nach und nach miteinander verweben.', 'Weitere Informationen, Leseproben und Kauflinks werden ergänzt, sobald sie verfügbar sind.', NULL, NULL, '2026-10-12 09:42:57'),
(5, 6, 'La Vie', 'Un livre sur la famille, les jumeaux et les destins humains qui s\'entrelacent peu à peu.', 'Des informations complémentaires, des extraits et des liens d\'achat seront ajoutés dès qu\'ils seront disponibles.', NULL, NULL, '2026-10-12 09:42:57'),
(6, 1, 'Láska — první díl: Kóma', 'První část trilogie o lásce, v níž se skutečnost a vnitřní svět začnou nečekaně prolínat.', 'První část trilogie o lásce, v níž se skutečnost a vnitřní svět začnou nečekaně prolínat.', 'Láska — první díl: Kóma', 'Láska — první díl: Kóma', '2026-10-12 07:02:10'),
(6, 2, 'Láska — prvý diel: Kóma', 'Prvá časť trilógie o láske, v ktorej sa skutočnosť a vnútorný svet začnú nečakane prelínať.', NULL, NULL, NULL, '2026-10-12 09:40:15'),
(6, 3, 'Miłość — część pierwsza: Śpiączka', 'Pierwsza część trylogii o miłości, w której rzeczywistość i świat wewnętrzny zaczynają się niespodziewanie przenikać.', 'Dodatkowe informacje, przykłady oraz linki do zakupu zostaną uzupełnione, gdy tylko będą dostępne.', NULL, NULL, '2026-10-12 09:40:15'),
(6, 4, 'Love — Part One: Coma', 'The first part of a trilogy about love, in which reality and the inner world begin to intertwine in unexpected ways.', NULL, NULL, NULL, '2026-10-12 09:40:15'),
(6, 5, 'Liebe — Teil Eins: Koma', 'Der erste Teil einer Trilogie über die Liebe, in der Realität und innere Welt auf unerwartete Weise miteinander verschmelzen.', NULL, NULL, NULL, '2026-10-12 09:40:15'),
(6, 6, 'L\'Amour — Première partie : Coma', 'La première partie d\'une trilogie sur l\'amour, dans laquelle la réalité et le monde intérieur commencent à s\'entremêler de manière inattendue.', NULL, NULL, NULL, '2026-10-12 09:40:15'),
(7, 1, 'Civilióza', 'Pohled na společnost, její pravidla a cenu, kterou za ně člověk platí.', NULL, NULL, NULL, '2026-10-12 07:08:55'),
(7, 2, '', 'Pohľad na spoločnosť, jej pravidlá a cenu, ktorú za ne človek platí.', NULL, NULL, NULL, '2026-10-12 09:38:08'),
(7, 3, '', 'Spojrzenie na społeczeństwo, jego zasady i cenę, jaką człowiek za nie płaci.', 'Dodatkowe informacje, przykłady oraz linki do zakupu zostaną uzupełnione, gdy tylko będą dostępne.', NULL, NULL, '2026-10-12 09:38:08'),
(7, 4, '', 'A look at society, its rules, and the price individuals pay for them.', NULL, NULL, NULL, '2026-10-12 09:38:08'),
(7, 5, '', 'Ein Blick auf die Gesellschaft, ihre Regeln und den Preis, den der Mensch dafür zahlt.', NULL, NULL, NULL, '2026-10-12 09:38:08'),
(7, 6, '', 'Un regard sur la société, ses règles et le prix que l\'on paie pour les respecter.', NULL, NULL, NULL, '2026-10-12 09:38:08'),
(8, 1, 'Stupně vědomí', 'Kniha věnovaná lidskému vnímání, vnitřní proměně a porozumění.', NULL, 'Civilióza', 'Civilióza', '2026-10-12 09:36:13'),
(8, 2, 'Stupne vedomia', 'Kniha venovaná ľudskému vnímaniu, vnútornej premene a porozumeniu.', NULL, NULL, NULL, '2026-10-12 09:37:04'),
(8, 3, 'Poziomy świadomości', 'Książka poświęcona ludzkiemu postrzeganiu, wewnętrznej przemianie i zrozumieniu.', 'Dodatkowe informacje, przykłady oraz linki do zakupu zostaną uzupełnione, gdy tylko będą dostępne.', NULL, NULL, '2026-10-12 09:37:04'),
(8, 4, 'Levels of Consciousness', 'A book dedicated to human perception, inner transformation, and understanding.', NULL, NULL, NULL, '2026-10-12 09:37:04'),
(8, 5, 'Bewusstseinsstufen', 'Ein Buch über die menschliche Wahrnehmung, innere Wandlung und Verständnis.', NULL, NULL, NULL, '2026-10-12 09:37:04'),
(8, 6, 'Les niveaux de conscience', 'Un livre consacré à la perception humaine, à la transformation intérieure et à la compréhension.', NULL, NULL, NULL, '2026-10-12 09:37:04'),
(9, 1, 'Mezi psychopaty', 'Román o partnerských vztazích, manipulaci, lidské odvaze a psychopatech mezi námi.', 'Román o partnerských vztazích, manipulaci, lidské odvaze a psychopatech mezi námi.', 'Mezi psychopaty', 'Mezi psychopaty', '2026-10-12 07:11:26'),
(9, 2, 'Medzi psychopatmi', 'Román o partnerských vzťahoch, manipulácii, ľudskej odvahe a psychopatoch medzi nami.', NULL, NULL, NULL, '2026-10-12 09:33:15'),
(9, 3, 'Wśród psychopatów', 'Powieść o związkach partnerskich, manipulacji, ludzkiej odwadze i psychopatach wśród nas.', 'Dodatkowe informacje, przykłady oraz linki do zakupu zostaną uzupełnione, gdy tylko będą dostępne.', NULL, NULL, '2026-10-12 09:33:15'),
(9, 4, 'Among Psychopaths', 'A novel about romantic relationships, manipulation, human courage, and the psychopaths among us.', NULL, NULL, NULL, '2026-10-12 09:33:15'),
(9, 5, 'Unter Psychopathen', 'Ein Roman über Partnerschaften, Manipulation, menschlichen Mut und Psychopathen unter uns.', NULL, NULL, NULL, '2026-10-12 09:33:15'),
(9, 6, 'Parmi les psychopathes', 'Un roman sur les relations amoureuses, la manipulation, le courage humain et les psychopathes parmi nous.', NULL, NULL, NULL, '2026-10-12 09:33:15');

-- --------------------------------------------------------

--
-- Struktura tabulky `product_variants`
--

CREATE TABLE `product_variants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `kind` enum('print','ebook','audio') COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isbn` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ean` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(12,2) NOT NULL,
  `sale_price` decimal(12,2) DEFAULT NULL,
  `sale_starts_at` datetime DEFAULT NULL,
  `sale_ends_at` datetime DEFAULT NULL,
  `currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CZK',
  `vat_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `stock_quantity` int(10) UNSIGNED DEFAULT NULL,
  `minimum_stock` int(10) UNSIGNED DEFAULT NULL,
  `weight_grams` int(10) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `product_variants`
--

INSERT INTO `product_variants` (`id`, `product_id`, `kind`, `sku`, `isbn`, `ean`, `price`, `sale_price`, `sale_starts_at`, `sale_ends_at`, `currency`, `vat_rate`, `stock_quantity`, `minimum_stock`, `weight_grams`, `active`, `created`, `updated`) VALUES
(1, 1, 'print', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, 10, 1, 400, 1, '2026-10-08 09:26:23', '2026-10-12 06:53:55'),
(2, 1, 'ebook', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 1, '2026-10-08 09:26:23', '2026-10-12 06:53:55'),
(3, 1, 'audio', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 1, '2026-10-08 09:26:23', '2026-10-12 06:53:55'),
(7, 2, 'ebook', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 1, '2026-10-09 07:20:24', '2026-10-12 06:54:15'),
(8, 2, 'audio', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 1, '2026-10-09 07:20:24', '2026-10-12 06:54:15'),
(13, 3, 'print', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, 30, NULL, NULL, 1, '2026-10-09 10:21:09', '2026-10-09 10:21:09'),
(14, 3, 'ebook', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 1, '2026-10-09 10:21:09', '2026-10-12 06:54:31'),
(15, 3, 'audio', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 1, '2026-10-09 10:21:09', '2026-10-12 06:54:31'),
(24, 4, 'audio', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 1, '2026-10-12 06:55:52', '2026-10-12 06:55:52'),
(27, 5, 'ebook', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 1, '2026-10-12 06:59:33', '2026-10-12 06:59:33'),
(28, 6, 'print', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, 10, NULL, NULL, 1, '2026-10-12 07:02:10', '2026-10-12 07:02:10'),
(29, 6, 'ebook', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 1, '2026-10-12 07:02:10', '2026-10-12 07:02:10'),
(30, 6, 'audio', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 1, '2026-10-12 07:02:10', '2026-10-12 07:02:10'),
(35, 5, 'print', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, 10, NULL, NULL, 1, '2026-10-12 07:04:17', '2026-10-12 07:04:17'),
(37, 5, 'audio', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 1, '2026-10-12 07:04:17', '2026-10-12 07:04:17'),
(41, 4, 'print', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, 30, NULL, NULL, 1, '2026-10-12 07:04:51', '2026-10-13 10:55:43'),
(42, 4, 'ebook', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 1, '2026-10-12 07:04:51', '2026-10-12 07:04:51'),
(67, 7, 'print', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, 10, NULL, NULL, 1, '2026-10-12 07:08:55', '2026-10-12 07:08:55'),
(68, 7, 'ebook', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 1, '2026-10-12 07:08:55', '2026-10-12 07:08:55'),
(69, 7, 'audio', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 1, '2026-10-12 07:08:55', '2026-10-12 07:08:55'),
(70, 8, 'print', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, 10, NULL, NULL, 1, '2026-10-12 07:09:51', '2026-10-12 07:09:51'),
(71, 8, 'ebook', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 1, '2026-10-12 07:09:51', '2026-10-12 07:09:51'),
(72, 8, 'audio', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 1, '2026-10-12 07:09:51', '2026-10-12 07:09:51'),
(73, 9, 'print', NULL, NULL, NULL, 295.00, NULL, NULL, NULL, 'CZK', 0.00, 10, NULL, NULL, 1, '2026-10-12 07:11:26', '2026-10-12 07:11:26'),
(74, 9, 'ebook', NULL, NULL, NULL, 295.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 0, '2026-10-12 07:11:26', '2026-10-16 18:02:33'),
(77, 9, 'audio', NULL, NULL, NULL, 295.00, NULL, NULL, NULL, 'CZK', 0.00, NULL, NULL, NULL, 0, '2026-10-12 07:13:58', '2026-10-16 18:02:33'),
(78, 2, 'print', NULL, NULL, NULL, 300.00, NULL, NULL, NULL, 'CZK', 0.00, 10, NULL, NULL, 1, '2026-10-12 07:14:11', '2026-10-12 07:14:11');

-- --------------------------------------------------------

--
-- Struktura tabulky `rac_digital_admin_hidden_orders`
--

CREATE TABLE `rac_digital_admin_hidden_orders` (
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `hidden_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Vypisuji data pro tabulku `rac_digital_admin_hidden_orders`
--

INSERT INTO `rac_digital_admin_hidden_orders` (`order_id`, `hidden_at`) VALUES
(17, '2026-10-16 21:44:56');

-- --------------------------------------------------------

--
-- Struktura tabulky `rac_hidden_test_payments`
--

CREATE TABLE `rac_hidden_test_payments` (
  `payment_id` bigint(20) UNSIGNED NOT NULL,
  `hidden_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktura tabulky `shipping_methods`
--

CREATE TABLE `shipping_methods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('pickup_point','address','personal') COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '100',
  `max_weight_grams` int(10) UNSIGNED DEFAULT NULL,
  `logo_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `shipping_methods`
--

INSERT INTO `shipping_methods` (`id`, `code`, `type`, `active`, `sort_order`, `max_weight_grams`, `logo_path`, `created_at`, `updated_at`) VALUES
(1, 'na_adresu', 'address', 1, 1, NULL, NULL, '2026-10-09 07:40:22', '2026-10-09 07:46:32'),
(2, 'zasilkovna', 'pickup_point', 0, 2, NULL, NULL, '2026-10-09 07:47:20', '2026-10-14 09:41:11'),
(3, 'osobni_odber', 'personal', 1, 3, NULL, NULL, '2026-10-09 07:47:43', '2026-10-09 09:15:12');

-- --------------------------------------------------------

--
-- Struktura tabulky `shipping_method_translations`
--

CREATE TABLE `shipping_method_translations` (
  `method_id` bigint(20) UNSIGNED NOT NULL,
  `language_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `shipping_method_translations`
--

INSERT INTO `shipping_method_translations` (`method_id`, `language_id`, `name`, `description`) VALUES
(1, 1, 'Doručení na adresu', NULL),
(2, 1, 'Zásilkovna', NULL),
(3, 1, 'Osobní odběr', NULL);

-- --------------------------------------------------------

--
-- Struktura tabulky `shipping_rates`
--

CREATE TABLE `shipping_rates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `method_id` bigint(20) UNSIGNED NOT NULL,
  `country_code` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CZK',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `free_from` decimal(12,2) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `shipping_rates`
--

INSERT INTO `shipping_rates` (`id`, `method_id`, `country_code`, `currency`, `price`, `free_from`, `active`) VALUES
(1, 1, 'CZ', 'CZK', 80.00, NULL, 1),
(3, 2, 'CZ', 'CZK', 100.00, NULL, 1),
(5, 3, 'CZ', 'CZK', 0.00, NULL, 1);

-- --------------------------------------------------------

--
-- Struktura tabulky `shop_digital_access`
--

CREATE TABLE `shop_digital_access` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `file_id` bigint(20) UNSIGNED NOT NULL,
  `token_hash` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_encrypted` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `download_count` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `last_download_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `shop_digital_access`
--

INSERT INTO `shop_digital_access` (`id`, `order_id`, `file_id`, `token_hash`, `token_encrypted`, `expires_at`, `revoked_at`, `download_count`, `last_download_at`, `created_at`) VALUES
(1, 5, 1, '8c6e056d97e66cabecdbc175bebd9be90c8b057779da5c5d4533eb683fc31f17', 'qsLHF2bXtEMYznLiJsO6I2a0s97hk7UeBmz82IQHk+5ZaR+bGRfJLK1pdRjlVeu9lX61b8UDSeEFQb9/39wlTbEkf1a7osfOEFkb3/rPncplDLRXSsGBd8cWHMM=', '2026-11-15 10:00:39', NULL, 2, '2026-10-16 10:07:34', '2026-10-16 08:00:39'),
(2, 6, 2, '00e1bd762140382560f629061f1d7f6fc91a15aed471fae5ea266c241471408d', 'wZRcFZNPf+PmDVDjfgioUauNapXXzi/fZ3dMLy8acSz12B1MMNl+bUaLShIHcjh3LwFJQPHvdX1v/arQCdBNsEWPbThDz8P0UfyJjw4U1ZJpwmjKzhHRKcqzoyw=', '2026-11-15 12:00:01', NULL, 3, '2026-10-16 15:24:51', '2026-10-16 10:00:01'),
(3, 10, 2, '2aa3b5691da61bbc5eebeb17d960eec644b166ca020fd481f4e4707d194624f3', '0BGJcLry6S6w4GXR7onuerUoR/AWAYxPPgtiJWxuwh+RN3LgGMWpJoA3oSRLuCeIvwhTRBs9elD9DZm0m9kjhPmHeks5c0NTI+4XL6xsrLjgrvjL+we3EzecnDg=', '2026-11-15 15:50:09', NULL, 0, NULL, '2026-10-16 13:50:09'),
(4, 12, 1, 'a9bdfa241a70853fca39182ebbd860a83f41e3a82378406da0c426a63bcefdca', 'wbGM5R1YhMzU0+3SvE4Hp+aAaezZPsdHCDkwZsa7UOagBFI2Bff4EwoDBPtoONube8WxO8mvxOh/Niy7U1CgIvah8lrvT02kCTQ2fw/xFU+2C0+R6KGTKva8yzY=', '2026-11-15 17:43:43', NULL, 2, '2026-10-16 18:27:26', '2026-10-16 15:43:43');

-- --------------------------------------------------------

--
-- Struktura tabulky `shop_digital_mail_log`
--

CREATE TABLE `shop_digital_mail_log` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `recipient` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` enum('manual','webhook') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('sending','accepted','failed') COLLATE utf8mb4_unicode_ci NOT NULL,
  `error_code` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sent_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `shop_digital_mail_log`
--

INSERT INTO `shop_digital_mail_log` (`id`, `order_id`, `recipient`, `source`, `status`, `error_code`, `created_at`, `sent_at`) VALUES
(1, 6, 'milan.smiesko@seznam.cz', 'manual', 'failed', 'Nelze se připojit k SMTP serveru.', '2026-10-16 10:31:17', NULL),
(2, 6, 'milan.smiesko@seznam.cz', 'manual', 'failed', 'Nelze se připojit k SMTP serveru.', '2026-10-16 10:34:39', NULL),
(3, 6, 'milan.smiesko@seznam.cz', 'manual', 'failed', 'Nelze se připojit k SMTP serveru.', '2026-10-16 10:35:03', NULL),
(4, 6, 'milan.smiesko@seznam.cz', 'manual', 'accepted', NULL, '2026-10-16 12:50:39', '2026-10-16 14:50:39'),
(5, 6, 'milan.smiesko@seznam.cz', 'manual', 'accepted', NULL, '2026-10-16 13:03:25', '2026-10-16 15:03:25'),
(6, 6, 'milan.smiesko@seznam.cz', 'manual', 'accepted', NULL, '2026-10-16 13:24:14', '2026-10-16 15:24:14'),
(7, 12, 'milan.smiesko@seznam.cz', 'webhook', 'failed', 'Neplatný UTF-8 text e-mailu.', '2026-10-16 15:43:43', NULL),
(8, 12, 'milan.smiesko@seznam.cz', 'manual', 'failed', 'Neplatné UTF-8 v poli from_name. Opravte zdrojový údaj v UTF-8; obsah není vypisován.', '2026-10-16 15:54:28', NULL),
(9, 12, 'milan.smiesko@seznam.cz', 'manual', 'accepted', NULL, '2026-10-16 15:57:33', '2026-10-16 17:57:33'),
(10, 12, 'milan.smiesko@seznam.cz', 'webhook', 'accepted', NULL, '2026-10-16 16:25:24', '2026-10-16 18:25:25');

-- --------------------------------------------------------

--
-- Struktura tabulky `shop_digital_retry_log`
--

CREATE TABLE `shop_digital_retry_log` (
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `attempts` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `last_result` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_error` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_attempt_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `shop_orders`
--

CREATE TABLE `shop_orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_number` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'awaiting_payment',
  `email` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_country` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_street` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_city` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_postal` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_same_as_shipping` tinyint(1) NOT NULL DEFAULT '1',
  `billing_name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `billing_street` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `billing_city` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `billing_postal` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `billing_country` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `billing_company` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_company_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_vat_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_method_id` bigint(20) UNSIGNED DEFAULT NULL,
  `shipping_method_name` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_type` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pickup_point` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `subtotal` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `shop_orders`
--

INSERT INTO `shop_orders` (`id`, `order_number`, `status`, `email`, `phone`, `customer_first_name`, `customer_last_name`, `shipping_country`, `shipping_street`, `shipping_city`, `shipping_postal`, `billing_same_as_shipping`, `billing_name`, `billing_street`, `billing_city`, `billing_postal`, `billing_country`, `billing_company`, `billing_company_id`, `billing_vat_id`, `shipping_method_id`, `shipping_method_name`, `shipping_type`, `pickup_point`, `shipping_price`, `subtotal`, `total`, `currency`, `customer_note`, `created_at`) VALUES
(3, 'RAC-261015-09191698DD', 'paid', 'milan.smiesko@seznam.cz', '774361633', 'nn', 'nn', NULL, NULL, NULL, NULL, 0, 'nnn', 'Ve Fisnkých 1826', 'Petřvald', '73541', 'CZ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 900.00, 900.00, 'CZK', NULL, '2026-10-15 08:15:04'),
(4, 'RAC-261015-8BBA117771', 'paid', 'michal.wagner@seznam.cz', '778778778', 'Michal', 'Wágner', NULL, NULL, NULL, NULL, 0, 'Michal Wágner', 'ulice 18', 'Ostrava', '73000', 'CZ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 295.00, 295.00, 'CZK', NULL, '2026-10-15 11:23:44'),
(5, 'RAC-261016-F602D289F3', 'paid', 'jindra@seznam.cz', '123456789', 'Jindra', 'Hudeček', NULL, NULL, NULL, NULL, 0, 'Jindřich Hudeček', 'doma 45', 'Brno', '90050', 'CZ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 300.00, 300.00, 'CZK', NULL, '2026-10-16 07:59:26'),
(6, 'RAC-261016-597358DD6F', 'paid', 'milan.smiesko@seznam.cz', '777777888', 'Milan', 'Smieško', NULL, NULL, NULL, NULL, 0, 'Milan  Smieško', 'Ve Finských 1826', 'Petřvald', '73541', 'CZ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 300.00, 300.00, 'CZK', NULL, '2026-10-16 09:57:30'),
(7, 'RAC-261016-024F3CD034', 'paid', 'milan.smiesko@seznam.cz', '728024400', 'Jindřich', 'Hudeček', NULL, NULL, NULL, NULL, 0, 'Milan  Smieško', '325', 'Makrvartovice', '747 14', 'CZ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 300.00, 300.00, 'CZK', NULL, '2026-10-16 13:22:12'),
(8, 'RAC-261016-5A47D7B374', 'paid', 'milan.smiesko@seznam.cz', '728024400', 'Aleš', 'Hradil', NULL, NULL, NULL, NULL, 0, 'Aleš Hradil', '325', 'Makrvartovice', '747 14', 'CZ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 300.00, 300.00, 'CZK', NULL, '2026-10-16 13:30:16'),
(9, 'RAC-261016-4017259C73', 'paid', 'milan.smiesko@seznam.cz', '728024400', 'Jindřich', 'Hudeček', NULL, NULL, NULL, NULL, 0, 'Testovací nákup', '325', 'Makrvartovice', '747 14', 'CZ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 300.00, 300.00, 'CZK', NULL, '2026-10-16 13:37:19'),
(10, 'RAC-261016-856DAE2410', 'paid', 'serp24.cz@gmail.com', '777898989', 'Marcel', 'Jonas', NULL, NULL, NULL, NULL, 0, 'Gmail Pokus', 'Jaselská 154/2', 'Opava Předměstí', '74601', 'CZ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 300.00, 300.00, 'CZK', NULL, '2026-10-16 13:41:41'),
(11, 'RAC-261016-7AD2B38A1B', 'paid', 'milan.smiesko@seznam.cz', '728024400', 'Jindřich', 'Hudeček', NULL, NULL, NULL, NULL, 0, 'Milan  Smieško2', '325', 'Makrvartovice', '747 14', 'CZ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 1500.00, 1500.00, 'CZK', NULL, '2026-10-16 13:58:59'),
(12, 'RAC-261016-692F124876', 'paid', 'milan.smiesko@seznam.cz', '7774558558', 'Karin', 'Malá', NULL, NULL, NULL, NULL, 0, 'Karin Malá', 'doma 45', 'ostrava', '70030', 'CZ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 600.00, 600.00, 'CZK', NULL, '2026-10-16 15:24:51'),
(13, 'RAC-261016-4412599095', 'awaiting_payment', 'milan.smiesko@seznam.cz', '728024400', 'Jindřich', 'Hudeček', NULL, NULL, NULL, NULL, 0, 'Aleš Hradil', '325', 'Makrvartovice', '747 14', 'CZ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 900.00, 900.00, 'CZK', NULL, '2026-10-16 16:00:35'),
(14, 'RAC-261016-1FD0BB2E8D', 'awaiting_payment', 'milan.smiesko@seznam.cz', '728024400', 'Jindřich', 'Hudeček', 'CZ', '325', 'Makrvartovice', '747 14', 1, 'safa', '325', 'Makrvartovice', '747 14', 'CZ', NULL, NULL, NULL, 3, 'Osobní odběr', 'personal', NULL, 0.00, 600.00, 600.00, 'CZK', NULL, '2026-10-16 16:02:24'),
(15, 'RAC-261016-F5E5AA4A6D', 'awaiting_payment', 'milan.smiesko@seznam.cz', '789456122', 'Marcel', 'Jonas', NULL, NULL, NULL, NULL, 0, 'Testovací nákup3', 'Jaselská 154/2', 'Opava Předměstí', '74601', 'CZ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 300.00, 300.00, 'CZK', NULL, '2026-10-16 16:09:37'),
(16, 'RAC-261016-611E836358', 'paid', 'milan.smiesko@seznam.cz', '728024400', 'Jindřich', 'Hudeček', 'CZ', '325', 'Makrvartovice', '747 14', 1, '98', '325', 'Makrvartovice', '747 14', 'CZ', NULL, NULL, NULL, 3, 'Osobní odběr', 'personal', NULL, 0.00, 300.00, 300.00, 'CZK', NULL, '2026-10-16 16:24:31'),
(17, 'RAC-261016-D72F6159FF', 'awaiting_payment', 'milan.smiesko@seznam.cz', '789456321', 'Marcel', 'Jonas', NULL, NULL, NULL, NULL, 0, 'ddd', 'Jaselská 154/2', 'Opava Předměstí', '74601', 'CZ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.00, 300.00, 300.00, 'CZK', NULL, '2026-10-16 16:25:56'),
(18, 'RAC-261019-C1EE6F55C3', 'awaiting_payment', 'serp24.cz@gmail.com', '774361636', 'Milan', 'Smieško', 'CZ', 'Ve Finských 1826', 'Petřvald', '735 41', 1, 'Milan Smieško', 'Ve Finských 1826', 'Petřvald', '735 41', 'CZ', NULL, NULL, NULL, 3, 'Osobní odběr', 'personal', NULL, 0.00, 300.00, 300.00, 'CZK', NULL, '2026-10-19 11:14:43');

-- --------------------------------------------------------

--
-- Struktura tabulky `shop_order_fulfillment`
--

CREATE TABLE `shop_order_fulfillment` (
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `fulfillment_status` enum('new','processing','shipped','completed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `carrier` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tracking_number` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_note` text COLLATE utf8mb4_unicode_ci,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `shipped_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `shop_order_fulfillment`
--

INSERT INTO `shop_order_fulfillment` (`order_id`, `fulfillment_status`, `carrier`, `tracking_number`, `admin_note`, `updated_by`, `shipped_at`, `completed_at`, `created_at`, `updated_at`) VALUES
(5, 'completed', NULL, NULL, NULL, NULL, NULL, '2026-10-16 10:00:39', '2026-10-16 08:00:39', '2026-10-16 08:00:39'),
(6, 'completed', NULL, NULL, NULL, NULL, NULL, '2026-10-16 12:00:01', '2026-10-16 10:00:01', '2026-10-16 10:00:01'),
(10, 'completed', NULL, NULL, NULL, NULL, NULL, '2026-10-16 15:50:09', '2026-10-16 13:50:09', '2026-10-16 13:50:09'),
(12, 'completed', NULL, NULL, NULL, NULL, NULL, '2026-10-16 17:43:43', '2026-10-16 15:43:43', '2026-10-16 15:43:43');

-- --------------------------------------------------------

--
-- Struktura tabulky `shop_order_items`
--

CREATE TABLE `shop_order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `variant_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `variant_kind` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `line_total` decimal(12,2) NOT NULL,
  `currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `shop_order_items`
--

INSERT INTO `shop_order_items` (`id`, `order_id`, `product_id`, `variant_id`, `title`, `variant_kind`, `quantity`, `unit_price`, `line_total`, `currency`) VALUES
(4, 3, 2, 7, 'Poznej sám sebe. Pak pochopíš všechno. — Komunikace se sebou', 'ebook', 2, 300.00, 600.00, 'CZK'),
(5, 3, 5, 27, 'Život', 'ebook', 1, 300.00, 300.00, 'CZK'),
(6, 4, 9, 74, 'Mezi psychopaty', 'ebook', 1, 295.00, 295.00, 'CZK'),
(7, 5, 4, 42, 'Láska', 'ebook', 1, 300.00, 300.00, 'CZK'),
(8, 6, 4, 24, 'Láska', 'audio', 1, 300.00, 300.00, 'CZK'),
(9, 7, 4, 42, 'Láska', 'ebook', 1, 300.00, 300.00, 'CZK'),
(10, 8, 4, 42, 'Láska', 'ebook', 1, 300.00, 300.00, 'CZK'),
(11, 9, 4, 42, 'Láska', 'ebook', 1, 300.00, 300.00, 'CZK'),
(12, 10, 4, 24, 'Láska', 'audio', 1, 300.00, 300.00, 'CZK'),
(13, 11, 4, 42, 'Láska', 'ebook', 5, 300.00, 1500.00, 'CZK'),
(14, 12, 4, 42, 'Láska', 'ebook', 2, 300.00, 600.00, 'CZK'),
(15, 13, 4, 24, 'Láska', 'audio', 3, 300.00, 900.00, 'CZK'),
(16, 14, 4, 41, 'Láska', 'print', 2, 300.00, 600.00, 'CZK'),
(17, 15, 4, 24, 'Láska', 'audio', 1, 300.00, 300.00, 'CZK'),
(18, 16, 4, 41, 'Láska', 'print', 1, 300.00, 300.00, 'CZK'),
(19, 17, 4, 42, 'Láska', 'ebook', 1, 300.00, 300.00, 'CZK'),
(20, 18, 5, 35, 'Život', 'print', 1, 300.00, 300.00, 'CZK');

-- --------------------------------------------------------

--
-- Struktura tabulky `shop_payments`
--

CREATE TABLE `shop_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `provider` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'stripe',
  `environment` enum('test','live') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `checkout_session_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_intent_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_minor` bigint(20) UNSIGNED NOT NULL,
  `currency` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `shop_payments`
--

INSERT INTO `shop_payments` (`id`, `order_id`, `provider`, `environment`, `status`, `checkout_session_id`, `payment_intent_id`, `amount_minor`, `currency`, `created_at`, `updated_at`) VALUES
(1, 3, 'stripe', 'test', 'paid', 'cs_test_a1OLdDSDgcbDrTGajQky0npoWD8J5bJXa8ZxbqDqzlsdFqgu1gk1bIlJTS', 'pi_3UQk67RrdttDzBlz1tddaksN', 90000, 'CZK', '2026-10-15 08:31:20', '2026-10-15 08:33:13'),
(2, 4, 'stripe', 'test', 'paid', 'cs_test_a1VsCziknO0GLMPio6wjONYOTivTJ2ngIbaFed4fN2ftf7xCqtluv7zZmA', 'pi_3UQmmJRrdttDzBlz1SDrgpvV', 29500, 'CZK', '2026-10-15 11:23:51', '2026-10-15 11:24:57'),
(3, 5, 'stripe', 'test', 'paid', 'cs_test_a1EDnitoMQOvk3p6h8u9JDTmCdUwvC2I2SzRWcs2ChubPiVLe6aT4vuuCi', 'pi_3UR63fRrdttDzBlz0GKqt2zs', 30000, 'CZK', '2026-10-16 07:59:33', '2026-10-16 08:00:09'),
(4, 6, 'stripe', 'test', 'paid', 'cs_test_a1Ar1kCmTJJ33C7Ttzma0WWLQdvDHzch5w3Dhyxk4VE4usgPiyKUkS2ZrU', 'pi_3UR7uiRrdttDzBlz1LfDP7EI', 30000, 'CZK', '2026-10-16 09:57:33', '2026-10-16 09:59:03'),
(5, 7, 'stripe', 'test', 'paid', 'cs_test_a1t8xOwzWGPnbskDb9GB2qbFX0acpioo1ZKjkvweCGs1QfqsHWkhBWuLG6', 'pi_3URB5dRrdttDzBlz0akH6nSU', 30000, 'CZK', '2026-10-16 13:22:17', '2026-10-16 13:22:31'),
(6, 8, 'stripe', 'test', 'paid', 'cs_test_a1jmbI9rhPxltqGVGP7RW7ML49rMrkA7fsSbNJZVbWNi5rTv1zVNuiOisK', 'pi_3URBDkRrdttDzBlz1fIUztL9', 30000, 'CZK', '2026-10-16 13:30:26', '2026-10-16 13:30:54'),
(7, 9, 'stripe', 'test', 'paid', 'cs_test_a1TYwyjF0G9DVjnatJoZFRhbmPl20flry8nDNeg9rzO3jQi8Hf8RIrWALM', 'pi_3URBKKRrdttDzBlz0ePtzcGX', 30000, 'CZK', '2026-10-16 13:37:23', '2026-10-16 13:37:42'),
(8, 10, 'stripe', 'test', 'paid', 'cs_test_a1Pm1zD30mB5UuOd3VNNxqZpNS0q4ULxbKE6GRU0xLMpjB46lkbm2eJ8sp', 'pi_3URBObRrdttDzBlz1pDIqINJ', 30000, 'CZK', '2026-10-16 13:41:44', '2026-10-16 13:42:07'),
(9, 11, 'stripe', 'test', 'paid', 'cs_test_a1mDChdhOOH0zPVFDd7XmqhARB6nW5dZR6mdPLYhxtp2vZ8Aq5lMazxCLq', 'pi_3URBfURrdttDzBlz0KfdnR7c', 150000, 'CZK', '2026-10-16 13:59:10', '2026-10-16 13:59:33'),
(10, 12, 'stripe', 'test', 'paid', 'cs_test_a1pLipaeLNbJ3jzFV2EV7LGY5tVBETqvNJbBscurzRHH6AjtodM0D2UxUq', 'pi_3URD0HRrdttDzBlz1cxGVkql', 60000, 'CZK', '2026-10-16 15:24:54', '2026-10-16 15:25:07'),
(11, 16, 'stripe', 'test', 'paid', 'cs_test_a1KFXkCQYzF7esDBZFPsosl9icFyDZZJ7QQHwk2vBSghRb7gqPsQLLZJeO', 'pi_3URDw4RrdttDzBlz16g0s2sC', 30000, 'CZK', '2026-10-16 16:24:39', '2026-10-16 16:24:50'),
(12, 17, 'stripe', 'test', 'expired', 'cs_test_a138rDrlgUNZjgPihS1RVnZWEzmhpZ8gB86VagFHKGuV0zoiLmEBa0MuX5', NULL, 30000, 'CZK', '2026-10-16 16:26:01', '2026-10-17 16:26:02');

-- --------------------------------------------------------

--
-- Struktura tabulky `shop_payment_events`
--

CREATE TABLE `shop_payment_events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `stripe_event_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `environment` enum('test','live') COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `processed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jmeno` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prijmeni` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `heslo_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('superadmin','admin') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'admin',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `users`
--

INSERT INTO `users` (`id`, `username`, `jmeno`, `prijmeni`, `email`, `foto`, `heslo_hash`, `role`, `is_active`, `created`, `updated`, `last_login`) VALUES
(1, 'milan smieško', 'Milan', 'Smieško', 'serp24.cz@gmail.com', NULL, '$2y$10$3xH3G0YUwUYSTNGlYuo0B.NxqYv8yhwQRBkYT8K4K910omas.OqQC', 'superadmin', 1, '2026-10-07 11:37:46', '2026-10-20 09:11:30', '2026-10-20 09:11:30'),
(2, 'Štefan Rac', 'Štefan', 'Rac', 'stefan.rac1@gmail.com', NULL, '$2y$10$S/CPL47zY8/ltGRPNvcLiuDsLOVKmcNKEyDm5AhcXlwsYIJo3Azki', 'admin', 1, '2026-10-13 16:34:20', '2026-10-13 16:34:37', '2026-10-13 16:34:37');

--
-- Indexy pro exportované tabulky
--

--
-- Indexy pro tabulku `billing_customers`
--
ALTER TABLE `billing_customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_billing_customer_provider_user` (`provider`,`user_id`),
  ADD UNIQUE KEY `uq_billing_customer_provider_customer` (`provider`,`provider_customer_id`);

--
-- Indexy pro tabulku `billing_payments`
--
ALTER TABLE `billing_payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_billing_payment_provider_session` (`provider`,`provider_checkout_session_id`),
  ADD UNIQUE KEY `uq_billing_payment_provider_invoice` (`provider`,`provider_invoice_id`),
  ADD KEY `idx_billing_payment_user` (`user_id`),
  ADD KEY `idx_billing_payment_status` (`status`),
  ADD KEY `idx_billing_payment_intent` (`provider_payment_intent_id`),
  ADD KEY `idx_billing_payment_subscription` (`provider_subscription_id`),
  ADD KEY `idx_billing_payment_product_code` (`product_code`);

--
-- Indexy pro tabulku `billing_products`
--
ALTER TABLE `billing_products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_billing_products_code` (`code`),
  ADD KEY `idx_billing_products_active` (`active`),
  ADD KEY `idx_billing_products_type` (`payment_type`);

--
-- Indexy pro tabulku `billing_settings`
--
ALTER TABLE `billing_settings`
  ADD PRIMARY KEY (`setting_key`),
  ADD KEY `idx_billing_settings_secret` (`is_secret`),
  ADD KEY `idx_billing_settings_updated_by` (`updated_by`);

--
-- Indexy pro tabulku `billing_subscriptions`
--
ALTER TABLE `billing_subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_billing_subscription_provider_id` (`provider`,`provider_subscription_id`),
  ADD KEY `idx_billing_subscription_user` (`user_id`),
  ADD KEY `idx_billing_subscription_status` (`status`),
  ADD KEY `idx_billing_subscription_checkout` (`checkout_session_id`),
  ADD KEY `idx_billing_subscription_product` (`product_code`);

--
-- Indexy pro tabulku `billing_webhook_events`
--
ALTER TABLE `billing_webhook_events`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_billing_webhook_provider_event` (`provider`,`event_id`),
  ADD KEY `idx_billing_webhook_type` (`event_type`),
  ADD KEY `idx_billing_webhook_status` (`status`);

--
-- Indexy pro tabulku `contact_blocked_ips`
--
ALTER TABLE `contact_blocked_ips`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ux_contact_ip` (`ip_address`);

--
-- Indexy pro tabulku `contact_form_settings`
--
ALTER TABLE `contact_form_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexy pro tabulku `contact_form_subjects`
--
ALTER TABLE `contact_form_subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexy pro tabulku `eshop_stock_movements`
--
ALTER TABLE `eshop_stock_movements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_variant_created` (`variant_id`,`created_at`),
  ADD KEY `idx_created` (`created_at`);

--
-- Indexy pro tabulku `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_languages_code` (`code`),
  ADD KEY `idx_languages_active_sort` (`active`,`sort_order`),
  ADD KEY `idx_languages_default` (`is_default`);

--
-- Indexy pro tabulku `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_pages_code` (`code`),
  ADD KEY `idx_pages_active_sort` (`active`,`sort_order`);

--
-- Indexy pro tabulku `page_sections`
--
ALTER TABLE `page_sections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_page_section` (`page_id`,`code`),
  ADD KEY `idx_page_sections_sort` (`page_id`,`active`,`sort_order`);

--
-- Indexy pro tabulku `page_section_fields`
--
ALTER TABLE `page_section_fields`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_section_field` (`section_id`,`code`),
  ADD KEY `idx_section_fields_sort` (`section_id`,`sort_order`);

--
-- Indexy pro tabulku `page_section_field_translations`
--
ALTER TABLE `page_section_field_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_field_translation` (`field_id`,`language_id`),
  ADD KEY `idx_field_translation_language` (`language_id`);

--
-- Indexy pro tabulku `page_translations`
--
ALTER TABLE `page_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_page_translation` (`page_id`,`language_id`),
  ADD KEY `idx_page_translation_language` (`language_id`);

--
-- Indexy pro tabulku `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_products_slug` (`slug`),
  ADD KEY `idx_products_status` (`status`,`sort_order`);

--
-- Indexy pro tabulku `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_category_code` (`code`);

--
-- Indexy pro tabulku `product_category_translations`
--
ALTER TABLE `product_category_translations`
  ADD PRIMARY KEY (`category_id`,`language_id`),
  ADD KEY `fk_pct_language` (`language_id`);

--
-- Indexy pro tabulku `product_files`
--
ALTER TABLE `product_files`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_product_files_key` (`storage_key`),
  ADD KEY `idx_product_files_variant` (`variant_id`,`purpose`);

--
-- Indexy pro tabulku `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_product_images` (`product_id`,`is_primary`,`sort_order`);

--
-- Indexy pro tabulku `product_translations`
--
ALTER TABLE `product_translations`
  ADD PRIMARY KEY (`product_id`,`language_id`),
  ADD KEY `fk_pt_language` (`language_id`);

--
-- Indexy pro tabulku `product_variants`
--
ALTER TABLE `product_variants`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_variant_product_kind` (`product_id`,`kind`),
  ADD UNIQUE KEY `uq_variant_sku` (`sku`);

--
-- Indexy pro tabulku `rac_digital_admin_hidden_orders`
--
ALTER TABLE `rac_digital_admin_hidden_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexy pro tabulku `rac_hidden_test_payments`
--
ALTER TABLE `rac_hidden_test_payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexy pro tabulku `shipping_methods`
--
ALTER TABLE `shipping_methods`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_shipping_code` (`code`);

--
-- Indexy pro tabulku `shipping_method_translations`
--
ALTER TABLE `shipping_method_translations`
  ADD PRIMARY KEY (`method_id`,`language_id`),
  ADD KEY `fk_smt_language` (`language_id`);

--
-- Indexy pro tabulku `shipping_rates`
--
ALTER TABLE `shipping_rates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_shipping_rate` (`method_id`,`country_code`,`currency`);

--
-- Indexy pro tabulku `shop_digital_access`
--
ALTER TABLE `shop_digital_access`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_order_file` (`order_id`,`file_id`),
  ADD UNIQUE KEY `uq_token_hash` (`token_hash`),
  ADD KEY `idx_order_access` (`order_id`),
  ADD KEY `fk_access_file` (`file_id`);

--
-- Indexy pro tabulku `shop_digital_mail_log`
--
ALTER TABLE `shop_digital_mail_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_rac_digital_mail_order` (`order_id`,`created_at`);

--
-- Indexy pro tabulku `shop_digital_retry_log`
--
ALTER TABLE `shop_digital_retry_log`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexy pro tabulku `shop_orders`
--
ALTER TABLE `shop_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_number` (`order_number`),
  ADD KEY `idx_shop_orders_created` (`created_at`),
  ADD KEY `idx_shop_orders_email` (`email`);

--
-- Indexy pro tabulku `shop_order_fulfillment`
--
ALTER TABLE `shop_order_fulfillment`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexy pro tabulku `shop_order_items`
--
ALTER TABLE `shop_order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_soi_order` (`order_id`),
  ADD KEY `idx_soi_variant` (`variant_id`);

--
-- Indexy pro tabulku `shop_payments`
--
ALTER TABLE `shop_payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_shop_checkout_session` (`checkout_session_id`),
  ADD UNIQUE KEY `uq_shop_payment_intent` (`payment_intent_id`),
  ADD KEY `idx_shop_payments_order` (`order_id`);

--
-- Indexy pro tabulku `shop_payment_events`
--
ALTER TABLE `shop_payment_events`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_shop_stripe_event` (`stripe_event_id`),
  ADD KEY `idx_shop_event_payment` (`payment_id`);

--
-- Indexy pro tabulku `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_users_username` (`username`),
  ADD UNIQUE KEY `uq_users_email` (`email`),
  ADD KEY `idx_users_role` (`role`),
  ADD KEY `idx_users_active` (`is_active`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `billing_customers`
--
ALTER TABLE `billing_customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `billing_payments`
--
ALTER TABLE `billing_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `billing_products`
--
ALTER TABLE `billing_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `billing_subscriptions`
--
ALTER TABLE `billing_subscriptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `billing_webhook_events`
--
ALTER TABLE `billing_webhook_events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `contact_blocked_ips`
--
ALTER TABLE `contact_blocked_ips`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `contact_form_subjects`
--
ALTER TABLE `contact_form_subjects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `eshop_stock_movements`
--
ALTER TABLE `eshop_stock_movements`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pro tabulku `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pro tabulku `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pro tabulku `page_sections`
--
ALTER TABLE `page_sections`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pro tabulku `page_section_fields`
--
ALTER TABLE `page_section_fields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT pro tabulku `page_section_field_translations`
--
ALTER TABLE `page_section_field_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1482;

--
-- AUTO_INCREMENT pro tabulku `page_translations`
--
ALTER TABLE `page_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;

--
-- AUTO_INCREMENT pro tabulku `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pro tabulku `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `product_files`
--
ALTER TABLE `product_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pro tabulku `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pro tabulku `product_variants`
--
ALTER TABLE `product_variants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=161;

--
-- AUTO_INCREMENT pro tabulku `shipping_methods`
--
ALTER TABLE `shipping_methods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pro tabulku `shipping_rates`
--
ALTER TABLE `shipping_rates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pro tabulku `shop_digital_access`
--
ALTER TABLE `shop_digital_access`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pro tabulku `shop_digital_mail_log`
--
ALTER TABLE `shop_digital_mail_log`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pro tabulku `shop_orders`
--
ALTER TABLE `shop_orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT pro tabulku `shop_order_items`
--
ALTER TABLE `shop_order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pro tabulku `shop_payments`
--
ALTER TABLE `shop_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pro tabulku `shop_payment_events`
--
ALTER TABLE `shop_payment_events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Omezení pro exportované tabulky
--

--
-- Omezení pro tabulku `page_sections`
--
ALTER TABLE `page_sections`
  ADD CONSTRAINT `fk_page_sections_page` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `page_section_fields`
--
ALTER TABLE `page_section_fields`
  ADD CONSTRAINT `fk_section_fields_section` FOREIGN KEY (`section_id`) REFERENCES `page_sections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `page_section_field_translations`
--
ALTER TABLE `page_section_field_translations`
  ADD CONSTRAINT `fk_field_translations_field` FOREIGN KEY (`field_id`) REFERENCES `page_section_fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_field_translations_language` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`) ON UPDATE CASCADE;

--
-- Omezení pro tabulku `page_translations`
--
ALTER TABLE `page_translations`
  ADD CONSTRAINT `fk_page_translations_language` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_page_translations_page` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `product_category_translations`
--
ALTER TABLE `product_category_translations`
  ADD CONSTRAINT `fk_pct_category` FOREIGN KEY (`category_id`) REFERENCES `product_categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_pct_language` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`);

--
-- Omezení pro tabulku `product_files`
--
ALTER TABLE `product_files`
  ADD CONSTRAINT `fk_pf_variant` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE CASCADE;

--
-- Omezení pro tabulku `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `fk_pi_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Omezení pro tabulku `product_translations`
--
ALTER TABLE `product_translations`
  ADD CONSTRAINT `fk_pt_language` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`),
  ADD CONSTRAINT `fk_pt_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Omezení pro tabulku `product_variants`
--
ALTER TABLE `product_variants`
  ADD CONSTRAINT `fk_pv_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Omezení pro tabulku `shipping_method_translations`
--
ALTER TABLE `shipping_method_translations`
  ADD CONSTRAINT `fk_smt_language` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`),
  ADD CONSTRAINT `fk_smt_method` FOREIGN KEY (`method_id`) REFERENCES `shipping_methods` (`id`) ON DELETE CASCADE;

--
-- Omezení pro tabulku `shipping_rates`
--
ALTER TABLE `shipping_rates`
  ADD CONSTRAINT `fk_sr_method` FOREIGN KEY (`method_id`) REFERENCES `shipping_methods` (`id`) ON DELETE CASCADE;

--
-- Omezení pro tabulku `shop_digital_access`
--
ALTER TABLE `shop_digital_access`
  ADD CONSTRAINT `fk_access_file` FOREIGN KEY (`file_id`) REFERENCES `product_files` (`id`),
  ADD CONSTRAINT `fk_access_order` FOREIGN KEY (`order_id`) REFERENCES `shop_orders` (`id`) ON DELETE CASCADE;

--
-- Omezení pro tabulku `shop_digital_mail_log`
--
ALTER TABLE `shop_digital_mail_log`
  ADD CONSTRAINT `fk_rac_digital_mail_order` FOREIGN KEY (`order_id`) REFERENCES `shop_orders` (`id`) ON DELETE CASCADE;

--
-- Omezení pro tabulku `shop_digital_retry_log`
--
ALTER TABLE `shop_digital_retry_log`
  ADD CONSTRAINT `fk_rac_retry_order` FOREIGN KEY (`order_id`) REFERENCES `shop_orders` (`id`) ON DELETE CASCADE;

--
-- Omezení pro tabulku `shop_order_fulfillment`
--
ALTER TABLE `shop_order_fulfillment`
  ADD CONSTRAINT `fk_rac_fulfillment_order` FOREIGN KEY (`order_id`) REFERENCES `shop_orders` (`id`) ON DELETE CASCADE;

--
-- Omezení pro tabulku `shop_order_items`
--
ALTER TABLE `shop_order_items`
  ADD CONSTRAINT `fk_soi_order` FOREIGN KEY (`order_id`) REFERENCES `shop_orders` (`id`) ON DELETE CASCADE;

--
-- Omezení pro tabulku `shop_payments`
--
ALTER TABLE `shop_payments`
  ADD CONSTRAINT `fk_shop_payments_order` FOREIGN KEY (`order_id`) REFERENCES `shop_orders` (`id`);

--
-- Omezení pro tabulku `shop_payment_events`
--
ALTER TABLE `shop_payment_events`
  ADD CONSTRAINT `fk_shop_event_payment` FOREIGN KEY (`payment_id`) REFERENCES `shop_payments` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
